#include <stdio.h>
#include "holaprintlibrary.h" //convocamos la libreria de hola printlibrary
			      //el cual tiene el mensaje en el archivo holaprint
			      //para poder convocarlo
//Guerrero Cangas Sebastian
int main(){
	puts("prueba con shared object\n");
	print("Hola mundo con shared object\n");
	return 0;
}