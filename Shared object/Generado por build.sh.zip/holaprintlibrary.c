#include <stdio.h>

void print(char* cadena){
	printf("A SHARED LIBRARY: %s\n",cadena);
}