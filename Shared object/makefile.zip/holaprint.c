#include<stdio.h>

void print(char* cadena){
	printf("%s\n",cadena);
	
}