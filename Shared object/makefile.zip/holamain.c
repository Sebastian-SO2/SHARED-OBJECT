
#include "holaprint.h" //void print(char* cadeba);

int main(){
	print("Hola mundo desde main\n");
	return 0;
}